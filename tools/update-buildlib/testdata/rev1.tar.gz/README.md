# buildlib

Collection of makefiles for common helpers and patterns.

You can `include somefile.mk` for its goodies.

You can reference this project as a subtree in the client project like `git
subtree -P build/ add git@github.com:caffeine-storm/buildlib.git main`
